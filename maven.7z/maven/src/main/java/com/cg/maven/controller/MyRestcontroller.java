package com.cg.maven.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.maven.bean.Customer;
import com.cg.maven.service.CustomerService;

@RestController
public class MyRestcontroller {
	@Autowired
	CustomerService service;
	@RequestMapping(value="/welcome",method=RequestMethod.GET)
	public String printHello()
	{
		return "Hello";
	}
	
	@RequestMapping(value="/addCustomer",method=RequestMethod.POST,produces="application/json")
	public Customer addCustomer(@RequestBody Customer customer)
	{
	
		customer = service.addCustomer(customer);
		return customer;
		
	}
	@RequestMapping(value="/fetch",method=RequestMethod.GET,produces="application/json",consumes="application/json")
	public ArrayList<Customer> fetchAll()
	{
		ArrayList<Customer> cuslist=service.fetchAll();
		return cuslist;
	}
	@RequestMapping(value="/getById/{id}",method=RequestMethod.GET,produces="application/json")
	public Customer getByID(@PathVariable int id )
	{
		Customer customer=service.getById(id);
		return customer;
	}
	@RequestMapping(value="/remove/{id}",method=RequestMethod.GET,produces="application/json")
	public Customer remove(@PathVariable int id )
	{
		Customer customer=service.remove(id);
		return customer;
	}
	@RequestMapping(value="/update",method=RequestMethod.POST,produces="application/json",consumes="application/json")
	public Customer update(@RequestBody Customer customer)
	{
	
		customer = service.update(customer);
		return customer;
		
	}
	
}
