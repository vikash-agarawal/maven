package com.cg.maven.bean;

	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
	import javax.validation.constraints.NotNull;

	@Entity
	public class Customer {
		
		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		private int customerId;
		
		@NotNull(message="First name can not be null")
		private String firstName;
		
		private String lastName;
		
	
		private int age;
		
		private String mobileno;
		private String city;
		public Customer(String firstName, String lastName, int age, String mobileno, String city) {
			super();
			this.firstName = firstName;
			this.lastName = lastName;
			this.age = age;
			this.mobileno = mobileno;
			this.city = city;
		}
		public Customer() {
			
		}
		
		public int getCustomerId() {
			return customerId;
		}
		public void setCustomerId(int customerId) {
			this.customerId = customerId;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public int getAge() {
			return age;
		}
		public void setAge(int age) {
			this.age = age;
		}
		public String getMobileno() {
			return mobileno;
		}
		public void setMobileno(String mobileno) {
			this.mobileno = mobileno;
		}
		public String getCity() {
			return city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		@Override
		public String toString() {
			return "Customer [firstName=" + firstName + ", lastName=" + lastName + ", age=" + age + ", mobileno=" + mobileno
					+ ", city=" + city + "]";
		}
		
	}
