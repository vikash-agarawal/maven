package com.cg.maven.service;
	import java.util.ArrayList;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;
	import org.springframework.transaction.annotation.Transactional;

import com.cg.maven.bean.Customer;
import com.cg.maven.repo.CustomerRepository;

	@Transactional
	@Service("service")
	public class CustomerServiceImpl implements CustomerService {
		@Autowired
		CustomerRepository repo;
		
		
		public CustomerRepository getRepo() {
			return repo;
		}


		public void setRepo(CustomerRepository repo) {
			this.repo = repo;
		}
		
		

		@Override
		public Customer addCustomer(Customer customer) {
			
			return repo.addCustomer(customer);
		}


		@Override
		public ArrayList<Customer> fetchAll() {
			return repo.fetchAll();
		}


		@Override
		public Customer getById(int id) {
			// TODO Auto-generated method stub
			return repo.getById(id);
		}


		@Override
		public Customer update(Customer customer) {
			// TODO Auto-generated method stub
			return repo.update(customer);
		}


		@Override
		public Customer remove(int customerId) {
			// TODO Auto-generated method stub
			return repo.remove(customerId);
		}


	}

