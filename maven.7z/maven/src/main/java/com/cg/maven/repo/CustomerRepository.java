package com.cg.maven.repo;

import java.util.ArrayList;

import com.cg.maven.bean.Customer;

public interface CustomerRepository {
	public Customer addCustomer(Customer customer);
	public ArrayList<Customer> fetchAll();
	public Customer getById(int id);
	public Customer update(Customer customer);
	public Customer remove(int customerId);
}
