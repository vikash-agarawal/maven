package com.cg.maven.service;

import java.util.ArrayList;

import com.cg.maven.bean.Customer;

public interface CustomerService {
	public Customer addCustomer(Customer customer);
	public ArrayList<Customer> fetchAll();
	public Customer getById(int id);
	public Customer update(Customer customer);
	public Customer remove(int customerId);
}
