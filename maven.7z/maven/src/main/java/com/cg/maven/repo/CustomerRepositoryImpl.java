package com.cg.maven.repo;


	import java.util.ArrayList;

	import javax.persistence.EntityManager;
	import javax.persistence.PersistenceContext;
	import javax.persistence.TypedQuery;

	import org.springframework.stereotype.Repository;

import com.cg.maven.bean.Customer;


	@Repository
	public class CustomerRepositoryImpl implements CustomerRepository {

		@PersistenceContext
		EntityManager entitymanager;
		
		
		
		public EntityManager getEntitymanager() {
			return entitymanager;
		}



		public void setEntitymanager(EntityManager entitymanager) {
			this.entitymanager = entitymanager;
		}



		@Override
		public Customer addCustomer(Customer customer) {
			entitymanager.persist(customer);
			entitymanager.flush();
			return customer;
		}



		@Override
		public ArrayList<Customer> fetchAll() {
			String selALLQry= " SELECT cus FROM Customer cus";
			TypedQuery<Customer> tq = entitymanager.createQuery(selALLQry,Customer.class);
			ArrayList<Customer> cusList = (ArrayList<Customer>) tq.getResultList();
			return cusList ;
		}



		@Override
		public Customer getById(int id) {
			// TODO Auto-generated method stub
			Customer customer=entitymanager.find(Customer.class, id);
			
			return customer;
		}



		@Override
		public Customer update(Customer customer) {
				entitymanager.merge(customer);
				entitymanager.flush();
				return customer;
		}



		@Override
		public Customer remove(int customerId) {
			Customer customer= entitymanager.find(Customer.class, customerId);
			entitymanager.remove(customer);
			entitymanager.flush();
			return customer;
		}

	}

